package com.example.demo.practice_3;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class FeatureConfigDefaultProfileTest {

    @Autowired
    private ApplicationContext context;

    @Test
    void signupNotifierBeanExistsWhenFeatureIsEnabled() {
        // application.properties has app.features.signup-enabled=true, so the bean is present.
        assertThat(context.getBean(SignupNotifier.class)).isNotNull();
    }
}
