package com.example.demo.practice_3;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest
@ActiveProfiles("test")
class FeatureConfigTestProfileTest {

    @Autowired
    private ApplicationContext context;

    @Test
    void signupNotifierBeanIsAbsentWhenFeatureIsDisabled() {
        // application-test.properties has app.features.signup-enabled=false, so no bean.
        assertThatThrownBy(() -> context.getBean(SignupNotifier.class))
                .isInstanceOf(NoSuchBeanDefinitionException.class);
    }
}
