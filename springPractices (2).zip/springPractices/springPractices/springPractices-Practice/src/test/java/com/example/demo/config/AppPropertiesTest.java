package com.example.demo.config;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
class AppPropertiesTest {

    @Autowired
    private AppProperties appProperties;

    @Test
    void bindsValuesFromApplicationTestProperties() {
        assertThat(appProperties.getEnvironment()).isEqualTo("test");
        assertThat(appProperties.getApi().getBaseUrl()).isEqualTo("http://localhost:9090/api");
        assertThat(appProperties.getApi().getTimeoutMs()).isEqualTo(2000);
        assertThat(appProperties.getFeatures().isSignupEnabled()).isFalse();
    }
}
