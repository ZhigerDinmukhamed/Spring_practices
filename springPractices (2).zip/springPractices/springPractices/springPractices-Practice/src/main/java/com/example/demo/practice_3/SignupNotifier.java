package com.example.demo.practice_3;

/**
 * Whatever we do when a new user signs up.
 * Only registered as a bean when signup is actually enabled — see FeatureConfig.
 */
public interface SignupNotifier {
    String notify(String username);
}
