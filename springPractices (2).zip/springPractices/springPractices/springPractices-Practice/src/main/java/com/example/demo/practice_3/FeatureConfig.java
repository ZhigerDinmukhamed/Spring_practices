package com.example.demo.practice_3;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeatureConfig {

    /**
     * Only exists when app.features.signup-enabled=true (that's already the default in
     * application.properties, but application-test.properties turns it off).
     * So on the "test" profile this bean simply isn't created.
     */
    @Bean
    @ConditionalOnProperty(prefix = "app.features", name = "signup-enabled", havingValue = "true")
    public SignupNotifier signupNotifier() {
        return new SignupNotifierImpl();
    }
}
