package com.example.demo.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

/**
 * Typed binding for every {@code app.*} entry in application(-<profile>).properties.
 *
 * Using a dedicated class instead of scattering @Value("${...}") lookups gives us:
 *  - one place that documents every setting we own,
 *  - compile-time-checked field access instead of string keys,
 *  - fail-fast startup validation (see the jakarta.validation annotations below),
 *  - IDE autocomplete, thanks to spring-boot-configuration-processor.
 */
@Validated
@ConfigurationProperties(prefix = "app")
public class AppProperties {

    /** Human-readable app name, e.g. "demo". */
    @NotBlank
    private String name;

    /** Which environment this instance is running as: default / dev / test / prod. */
    @NotBlank
    private String environment = "default";

    @Valid
    private final Api api = new Api();

    @Valid
    private final Features features = new Features();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public Api getApi() {
        return api;
    }

    public Features getFeatures() {
        return features;
    }

    /** Settings for the API this app talks to (binds to app.api.*). */
    public static class Api {

        @NotBlank
        private String baseUrl;

        @Positive
        private int timeoutMs = 5000;

        public String getBaseUrl() {
            return baseUrl;
        }

        public void setBaseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
        }

        public int getTimeoutMs() {
            return timeoutMs;
        }

        public void setTimeoutMs(int timeoutMs) {
            this.timeoutMs = timeoutMs;
        }
    }

    /** Simple feature toggles (binds to app.features.*). */
    public static class Features {

        private boolean signupEnabled = true;

        public boolean isSignupEnabled() {
            return signupEnabled;
        }

        public void setSignupEnabled(boolean signupEnabled) {
            this.signupEnabled = signupEnabled;
        }
    }
}
