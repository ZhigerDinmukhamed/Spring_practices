package com.example.demo.practice_3;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class SignupController {

    // Optional, because SignupNotifier only exists as a bean when signup is enabled.
    // Injecting SignupNotifier directly would break Spring startup on profiles where it's off.
    private final Optional<SignupNotifier> signupNotifier;

    public SignupController(Optional<SignupNotifier> signupNotifier) {
        this.signupNotifier = signupNotifier;
    }

    @GetMapping("/signup")
    public String signup(@RequestParam String username) {
        return signupNotifier
                .map(notifier -> notifier.notify(username))
                .orElse("Signup is currently disabled.");
    }
}
