package com.example.demo.practice_2;

import com.example.demo.config.AppProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Hit GET /config after starting the app with different profiles
 * (e.g. --spring.profiles.active=dev or =test) to see the bound
 * AppProperties values change.
 */
@RestController
public class AppConfigController {

    private final AppProperties appProperties;

    public AppConfigController(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    @GetMapping("/config")
    public AppProperties config() {
        return appProperties;
    }
}
