package com.example.demo.practice_3;

public class SignupNotifierImpl implements SignupNotifier {

    @Override
    public String notify(String username) {
        return "Welcome, " + username + "!";
    }
}
