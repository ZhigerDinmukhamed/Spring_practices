package com.example.demo.sis;

import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class StudentService {
    private final Map<Long, StudentResponse> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong();

    public List<StudentResponse> findAll() {
        return store.values().stream().sorted(Comparator.comparing(StudentResponse::id)).toList();
    }

    public StudentResponse findById(Long id) {
        return Optional.ofNullable(store.get(id)).orElseThrow(() -> new NotFoundException(id));
    }

    public StudentResponse create(StudentRequest r) {
        long id = seq.incrementAndGet();
        StudentResponse s = new StudentResponse(id, r.name(), r.email(), r.age());
        store.put(id, s);
        return s;
    }

    public StudentResponse update(Long id, StudentRequest r) {
        findById(id);
        StudentResponse s = new StudentResponse(id, r.name(), r.email(), r.age());
        store.put(id, s);
        return s;
    }

    public void delete(Long id) {
        if (store.remove(id) == null) throw new NotFoundException(id);
    }
}
