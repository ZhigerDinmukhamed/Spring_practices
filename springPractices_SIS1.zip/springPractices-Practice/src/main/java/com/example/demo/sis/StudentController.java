package com.example.demo.sis;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final StudentService service;

    public StudentController(StudentService service) { this.service = service; }

    @GetMapping
    public List<StudentResponse> getAll() { return service.findAll(); }          // 200

    @GetMapping("/{id}")
    public StudentResponse getOne(@PathVariable Long id) { return service.findById(id); } // 200 / 404

    @PostMapping
    public ResponseEntity<StudentResponse> create(@Valid @RequestBody StudentRequest r) {
        StudentResponse s = service.create(r);
        var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(s.id());
        return ResponseEntity.created(uri).body(s);                               // 201 / 400
    }

    @PutMapping("/{id}")
    public StudentResponse update(@PathVariable Long id, @Valid @RequestBody StudentRequest r) {
        return service.update(id, r);                                             // 200 / 400 / 404
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();                                // 204 / 404
    }
}
