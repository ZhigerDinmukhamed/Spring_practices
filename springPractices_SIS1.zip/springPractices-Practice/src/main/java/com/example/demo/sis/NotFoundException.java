package com.example.demo.sis;

public class NotFoundException extends RuntimeException {
    public NotFoundException(Long id) { super("Student " + id + " not found"); }
}
