package com.example.demo.sis;

public record StudentResponse(Long id, String name, String email, Integer age) {}
