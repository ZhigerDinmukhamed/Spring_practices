package com.example.demo.sis;

import jakarta.validation.constraints.*;

public record StudentRequest(
        @NotBlank @Size(max = 50) String name,
        @NotBlank @Email String email,
        @NotNull @Min(16) @Max(100) Integer age) {}
